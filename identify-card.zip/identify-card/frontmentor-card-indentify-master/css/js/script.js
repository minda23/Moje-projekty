"use strict";

const fullName = document.getElementById("name-input");
const emailAdress = document.getElementById("email-input");
const github_username = document.getElementById("github-username");
const uploadPhoto = document.getElementById("form-upload");
const inputFile = document.getElementById("file-upload");
const imageAvatar = document.getElementById("image-avatar");
const imageArray = [];

document.addEventListener("DOMContentLoaded", function () {
    const submitButton = document.getElementById("btn-submit");

    submitButton.addEventListener("click", function (e) {
        e.preventDefault();

        const nameValue = fullName.value.trim();
        const emailValue = emailAdress.value.trim();
        const githubValue = github_username.value.trim();

        if (!nameValue) {
            alert("Please enter your full name.");
            fullName.focus();
            return;
        }

        if (!checkEmailAdress(emailValue)) {
            alert("Please enter a valid email address.");
            emailAdress.focus();
            return;
        }

        if (!checkgithubname(githubValue)) {
            github_username.focus();
            return;
        }

        const file = inputFile.files[0];
        if (file) {
            if (!checkAvatarPhoto(file)) {
                alert("Please upload a valid image file (jpg, jpeg, png, gif).");
                inputFile.focus();
                return;
            }
            if (file.size > 2 * 1024 * 1024) {
                alert("Avatar photo must be less than 2MB.");
                inputFile.focus();
                return;
            }
        }

        alert("Form submitted successfully!");
    });
});

function checkName(user) {
    const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
    if (!user) {
        alert("Please enter a username.");
        return false;
    }
    const isValid = usernameRegex.test(user);
    if (!isValid) {
        alert("Username must be 3-20 characters long and can include letters, numbers, and underscores.");
    }
    return isValid;
}

function checkEmailAdress(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const isValid = emailRegex.test(email);
    if (!isValid) {
        alert("Invalid email format.");
    }
    return isValid;
}

function checkgithubname(username) {
    const githubRegex = /^[a-zA-Z0-9-]{1,39}$/;
    if (!username) {
        alert("Please enter a GitHub username.");
        return false;
    }
    const isValid = githubRegex.test(username);
    if (!isValid) {
        alert("GitHub username must be 1-39 characters long and can include letters, numbers, and hyphens.");
    }
    return isValid;
}

function checkAvatarPhoto(file) {
    const allowedExtensions = ["jpg", "jpeg", "png", "gif"];
    const extension = file.name.split('.').pop().toLowerCase();
    const isValidExtension = allowedExtensions.includes(extension);
    if (!isValidExtension) {
        alert("Allowed image formats: jpg, jpeg, png, gif.");
    }
    return isValidExtension;
}

inputFile.onchange = function () {
    const files = inputFile.files;
    for (let i = 0; i < files.length; i++) {
        imageArray.push(files[i]);
    }

    if (imageArray.length > 0) {
        const reader = new FileReader();
        reader.onload = function (e) {
            imageAvatar.src = e.target.result;
        };
        reader.readAsDataURL(imageArray[0]);
    }
};
