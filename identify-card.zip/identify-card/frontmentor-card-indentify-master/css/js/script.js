"use strict";

/*
- Complete the form with their details
- Receive form validation messages if:
  - Any field is missed
  - The email address is not formatted correctly
  - The avatar upload is too big or the wrong image format
- Complete the form only using their keyboard
- Have inputs, form field hints, and error messages announced on their screen reader
- See the generated conference ticket when they successfully submit the form
- View the optimal layout for the interface depending on their device's screen size
- See hover and focus states for all interactive elements on the page


*/

const fullName = document.getElementById("name-input");
const emailAdress = document.getElementById("email-input");
const github_username = document.getElementById("github-username");
const uploadPhoto = document.getElementById("form-upload");
const inputFile = document.getElementById("file-upload");
const imageAvatar = document.getElementById("image-avatar");
const imageArray = [];

document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("form");

    form.addEventListener("submit", function (event) {

        const submitButton = document.getElementById("btn-submit");
        event.preventDefault();





        if (fullName === "") {

            alert("Name must be filled out");
            return;
        }



        if (!checkEmailAdress(emailValue)) {
            alert("Please enter a valid email address.");
            emailAdress.focus();
            return;
        }

        if (!checkgithubname(githubValue)) {
            github_username.focus();
            return;
        }

        const file = inputFile.files[0];
        if (file) {
            if (!checkAvatarPhoto(file)) {
                alert("Please upload a valid image file (jpg, jpeg, png, gif).");
                inputFile.focus();
                return;
            }
            if (file.size > 2 * 1024 * 1024) {
                alert("Avatar photo must be less than 2MB.");
                inputFile.focus();
                return;
            }
        }

        alert("Form submitted successfully!");
    });
});

function checkName(user) {
    const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
    if (!user) {
        alert("Please enter a username.");
        return false;
    }
    const isValid = usernameRegex.test(user);
    if (!isValid) {
        alert("Username must be 3-20 characters long and can include letters, numbers, and underscores.");
    }
    return isValid;
}

function checkEmailAdress(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const isValid = emailRegex.test(email);
    if (!isValid) {
        alert("Invalid email format.");
    }
    return isValid;
}

function checkgithubname(username) {
    const githubRegex = /^[a-zA-Z0-9-]{1,39}$/;
    if (!username) {
        alert("Please enter a GitHub username.");
        return false;
    }
    const isValid = githubRegex.test(username);
    if (!isValid) {
        alert("GitHub username must be 1-39 characters long and can include letters, numbers, and hyphens.");
    }
    return isValid;
}

function checkAvatarPhoto(file) {
    const allowedExtensions = ["jpg", "jpeg", "png", "gif"];
    const extension = file.name.split('.').pop().toLowerCase();
    const isValidExtension = allowedExtensions.includes(extension);
    if (!isValidExtension) {
        alert("Allowed image formats: jpg, jpeg, png, gif.");
    }
    return isValidExtension;
}

inputFile.onchange = function () {
    const files = inputFile.files;
    for (let i = 0; i < files.length; i++) {
        imageArray.push(files[i]);
    }

    if (imageArray.length > 0) {
        const reader = new FileReader();
        reader.onload = function (e) {
            imageAvatar.src = e.target.result;
        };
        reader.readAsDataURL(imageArray[0]);
    }
};
