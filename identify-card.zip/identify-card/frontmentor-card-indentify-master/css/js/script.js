"use strict";


/*
Your users should be able to: 

- Complete the form with their details
- Receive form validation messages if:
  - Any field is missed
  - The email address is not formatted correctly
  - The avatar upload is too big or the wrong image format
- Complete the form only using their keyboard
- Have inputs, form field hints, and error messages announced on their screen reader
- See the generated conference ticket when they successfully submit the form
- View the optimal layout for the interface depending on their device's screen size
- See hover and focus states for all interactive elements on the page
*/
const fullName = document.getElementById("name-input")
const emailAdress = document.getElementById("email-input")
const github_username = document.getElementById("github-username")
const uploadPhoto = document.getElementById("form-upload")
const inputFile = document.getElementById("file-upload")
const imageAvatar = document.getElementById("image-avatar")

document.addEventListener("DOMContentLoaded", function () {
    const submitButton = document.getElementById("btn-submit");

    submitButton.addEventListener("click", function (event) {
        event.preventDefault();
        if (!checkName(fullName.value)) {
            alert("Please enter a valid username. It should be 3-20 characters long and can contain letters, numbers, and underscores.");
        } else if (!checkEmailAdress(emailAdress.value)) {
            alert("Please enter a valid email address.");
        } else if (!checkgithubname(github_username.value)) {
            alert("Please enter a valid GitHub username.");
        } else {
            alert("Form submitted successfully!");
        }
    });
});


function checkName(user) {
    const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
    if (!user) {
        alert("Please enter a username.");
        return false;
    }
    return usernameRegex.test(user);
}


function checkEmailAdress(email) {

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}


function checkgithubname(username) {
    const githubRegex = /^[a-zA-Z0-9-]{1,39}$/;
    if (!username) {
        alert("Please enter a GitHub username.");
        return false;
    }
    return githubRegex.test(username);
}



function checkAvatarPhoto(file) {
    const allowedExtensions = ["jpg", "jpeg", "png", "gif"];
    const extension = file.name.split('.').pop().toLowerCase();
    return allowedExtensions.indexOf(extension) !== -1;

}


inputFile.onchange = function () {
    imageAvatar.src = URL.createObjectURL(inputFile.files[0])
}




