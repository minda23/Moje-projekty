"use strict";



let front_card = $("#cardfront");
let back_card = $("#cardback");
let user_data = $("input").val();






