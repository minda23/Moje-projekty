"use strict";


/*hamburger menu*/

let navigation = $("nav ul li");
let cross = $("#cross");
let burger_menu = $("#burger_menu");

burger_menu.css('opacity','1')
           
burger_menu.click(function(){
    console.log("ahoj");
  navigation.slideDown(1000);
  burger_menu.css('opacity','0')
  cross.css('opacity','1')

});

cross.click(function(){
    navigation.slideUp(1000);
    cross.css('opacity','0')

    if (true) {
        burger_menu.css('opacity','1')
    }
})


/*šipka navrch*/


let arrow = $("#navrch");
let arrow_down = $(".arrow")



$(document).scroll(function(){
   if ($(window).scrollTop() > 10) {
       arrow.css('opacity','1');
       arrow_down.css('display','none');

   }else {
        $('#arrow').css('opacity', '0'); // Hide the arrow when at the top
    }
});


   arrow.click(function(e){
        e.preventDefault()
        $('html, body').animate({ scrollTop: 0 }, 100);
   });


/*od kliknutia šipky na sekciu*/




/*overenie formulara*/


    $("#submit").click(function(){
            let name = $("#name").val();
            let email = $("#email").val();
            let pass = $("#password").val();

            if(name.length == "")
            {
                $("#p1").text("Please enter your name");
                $("#name").focus();
                return false;
            }

            else if(email.length == ""){
                $("#p2").text("Please enter your email address");
                $("#email").focus();
                return false;
            }


            else if(pass.length == ""){
                $("#p3").text("Please enter your password");
                $("#password").focus();
                return false;
            }

            else{
                var con = confirm("Are you Done?");
                if(con == true)
                {
                    alert("Welcome to our Website");
                    return true;
                }
                else{
                    return false;
                }
            }
        });


/*na vstup myšky zmena farby a pozadia*/




    $('.item_about').click(function() {
        console.log("ahoj")
                
                $(this).siblings().removeClass('active');
                $(this).addClass('active');
            });


/*animacie prichodu elementov na stránke*/
 
    
   

    
     
    let animationTriggered = false;
    let scrollDirectionDown = false;




       let sections = [
                { id: '#item_about1', trigger: 70},
                { id: '#item_about2', trigger: 300 },
                { id: '#item_about3', trigger: 500 },
                { id: '#item_about4', trigger: 750 }
            ];

        $(window).on('scroll', function () {
        // Animation for .časti_panela
          let scrollPositionY = $(this).scrollTop();

                sections.forEach(function(section) {
                    if (scrollPositionY >= section.trigger) {
                        $(section.id).css({
                            opacity: 1,
                            transform: "translateX(0%)"
                        });
                    }
                });
            });
let sections1;
     if (window.innerWidth <= 768) { 
    sections1 = [
        { id: '#project1', trigger: 1800 }, 
        { id: '#project2', trigger: 2000 },
        { id: '#project3', trigger: 2200 },
        { id: '#project4', trigger: 2400 },
        { id: '#project5', trigger: 2600 },
        { id: '#project6', trigger: 2700 }

    ];
} else {
    sections1 = [
        { id: '#project1', trigger: 1200 },
        { id: '#project2', trigger: 1400 },
        { id: '#project3', trigger: 1600 },
        { id: '#project4', trigger: 1700 },
        { id: '#project5', trigger: 1800 },
        { id: '#project6', trigger: 2000 }
    ];
}
        $(window).on('scroll', function () {
        // Animation for .časti_panela
          let scrollPositionY = $(this).scrollTop();

                sections1.forEach(function(section) {
                    if (scrollPositionY >= section.trigger) {
                        $(section.id).css({
                            opacity: 1,
                            transform: "translateX(0%)"
                        });
                    }
                });
            });

let sections2;

     if (window.innerWidth <= 768) { 
    sections2 = [
        { id: '#course', trigger: 2600 }, 
        { id: '#course1', trigger: 2800 },
        
    ];
} else {

         sections2 = [
                { id: '#course', trigger: 2200},
                { id: '#course1', trigger: 2500}
            ];
     }

        $(window).on('scroll', function () {
        // Animation for .časti_panela
          let scrollPositionY = $(this).scrollTop();

                sections2.forEach(function(section) {
                    if (scrollPositionY >= section.trigger) {
                        $(section.id).css({
                            opacity: 1,
                            transform: "translateX(0%)"
                        });
                    }
                });
            });
        

    /*animovanie textu */



            const heading = $("#heading");
            const text = "JUNIOR FRONTEND DEVELOPER & CODER";
            const speed = 120;
            let index = 0;
            let starttimetext;
            let timeoutId;

            function textmove() {
                if (index === 0) {
                    starttimetext = $.now();
                }

                heading.text(text.slice(0, index));
                index++;

                if (index > text.length) {
                    const endtimetext = $.now();
                    const resulttime = endtimetext - starttimetext;
                    console.log(resulttime);
                    clearTimeout(timeoutId);
                } else {
                    timeoutId = setTimeout(textmove, speed);
                }
            }

            textmove();
    
  


        