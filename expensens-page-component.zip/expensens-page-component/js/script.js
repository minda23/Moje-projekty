document.querySelectorAll('.diagram_container').forEach(container => {
    container.addEventListener('mouseover', function() {
        const priceOverlay = document.getElementById('price_overlay');
        priceOverlay.textContent = this.getAttribute('data-price');
        priceOverlay.style.display = 'block';
        const rect = this.getBoundingClientRect();
        priceOverlay.style.left = `${rect.left + rect.width / 2 - priceOverlay.offsetWidth / 2}px`;
        priceOverlay.style.top = `${rect.top - priceOverlay.offsetHeight - 10}px`;
    });

    container.addEventListener('mouseout', function() {
        const priceOverlay = document.getElementById('price_overlay');
        priceOverlay.style.display = 'none';
    });
});
