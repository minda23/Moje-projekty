"use strict";

const formControlFrom = document.getElementById("form_control");
const formControlTo = document.getElementById("form_control_to");
const convertBtn = document.getElementById("convert");
const resetBtn = document.getElementById("reset");
const amountInput = document.querySelector(".amount");

// Function to fetch currency data from an API
function fetchCurrencies() {
  const primary = formControlFrom.value;
  const secondary = formControlTo.value;
  const amount = amountInput.value;

  if (primary === "" || secondary === "" || amount === "") {
    alert("Please select both currencies and enter the amount.");
    return;
  }

  // Replace 'xxxxxxxxxxxxxxxxxxxxxx' with your actual API key
  fetch("https://v6.exchangerate-api.com/v6/639925a4be518cee51d016ca/latest/" + primary)
    .then((response) => {
      if (response.ok) {
        return response.json();
      } else {
        throw new Error("NETWORK RESPONSE ERROR");
      }
    })
    .then((data) => {
      displayCurrency(data, primary, secondary, amount);
    })
    .catch((error) => console.error("FETCH ERROR:", error));
}

// Function to display the conversion result
function displayCurrency(data, primary, secondary, amount) {
  const conversionRate = data.conversion_rates[secondary];
  const calculatedAmount = (amount * conversionRate).toFixed(2);

  // Create the result div
  const result = document.createElement("div");
  result.className = "result";
  result.innerHTML = `
    <h2>Conversion Result</h2>
    <p>${amount} ${primary} = ${calculatedAmount} ${secondary}</p>
  `;

  // Insert the result div after the buttons
  const buttonsDiv = document.querySelector(".buttons");
  buttonsDiv.insertAdjacentElement('afterend', result);
}

// Event listener for the Convert button
convertBtn.addEventListener("click", (e) => {
  e.preventDefault();
  fetchCurrencies();
});

// Event listener for the Reset button
resetBtn.addEventListener("click", (e) => {
  e.preventDefault();
  amountInput.value = "";
  formControlFrom.value = "";
  formControlTo.value = "";
  const resultDiv = document.querySelector(".result");
  if (resultDiv) {
    resultDiv.remove();
  }
});
