"use strict";



    /**
     * on click on button its gonna change functionality of button
     *
     * na kliknutie chceme vymazať stary obsah a pridat novy
     * 
     *
     * 
     * 
     * 
     */
let button = $(".item a");



button.click(function(){
    event.preventDefault()
    $(this).closest(button).css('background-color','#C73A0F')
    $(this).closest(button).html("")
    let addtext = $(this).html("<p>1</p>")
 let addbutton = $(this).html("<button style='dispay:block;text-align:left;border-radius:1rem;'>-</button>");
    $(this).append(addtext)

});


