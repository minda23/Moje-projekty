"use strict";



let button = $("#btn");


$(document).ready(function() {
    $('#btn').click(function() {
        $('#overlay').fadeIn();
    });

    $('#close').click(function() {
        $('#overlay').fadeOut();
    });

   
});

$(document).ready(function() {
  $('.arrow-button.prev').on('click', function() {
  	event.preventDefault()
    let prevPage = $(this).data('prev');
    console.log(prevPage)
    if (prevPage) {
      window.location.href = prevPage;
    }
  });

  $('.arrow-button.next').on('click', function() {
  	event.preventDefault()
    let nextPage = $(this).data('next');
    if (nextPage) {
      window.location.href = nextPage;
    }
  });
});


