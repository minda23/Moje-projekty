
function loadAllTasks() {
    let allTasks = localStorage.getItem("tasks");
    $("#taskList").html(allTasks);
}

function saveAllTasks() {
    let allTasks = $("#taskList").html();
    localStorage.setItem("tasks", allTasks);
}

let input_user = $("#myInput").val();
let add_task = $("#add_task");
let item;

// Load all tasks on page load.
loadAllTasks();

$('#add_task').click(function (e) {
    e.preventDefault();
    let inputVal = $('#myInput').val();
    if (inputVal.trim() !== "") {
        let newTask = $(
            '<li style="margin-top:1rem">' +
            '<img class="icon-left checked" src="checked.svg" style="display:none;">' +
            '<img class="icon-left empty" src="empty.svg">' +
            inputVal +
            '<img class="remove trash" src="trash.svg" >' +
            '</li>'
        );
        $('ul').append(newTask);
        $('#myInput').val('');

        saveAllTasks();
    }
});

$(document).on('click', '.remove.trash', function () {
    $(this).closest('li').remove();
    saveAllTasks();
});

$(document).on('click', '.icon-left.checked', function () {
    $(this).hide();
    $(this).siblings('.icon-left.empty').show();
    $(this).parent().css("text-decoration", "none");
    saveAllTasks();
});

$(document).on('click', '.icon-left.empty', function () {
    $(this).hide();
    $(this).siblings('.icon-left.checked').show();
    $(this).parent().css("text-decoration", "line-through");
    saveAllTasks();
});




