
"use strict";

/*
 
- Vyberte si predmet kvízu
- Vyberte jednu odpoveď na každú otázku zo štyroch možností
- Zobrazí sa chybová správa, keď sa pokúsite odoslať odpoveď bez výberu
- Uvidíte, či ste urobili správnu alebo nesprávnu voľbu, keď odošlete odpoveď
- Prejdite na ďalšiu otázku po zobrazení výsledku otázky
- Po poslednej otázke uvidíte dokončený stav s výsledkom
- Hrajte znova, aby ste si vybrali iný predmet
- Zobrazte optimálne rozloženie rozhrania v závislosti od veľkosti obrazovky vášho zariadenia
- Zobrazte stavy prechodu myšou a zamerania pre všetky interaktívne prvky na stránke
- Navigujte celú aplikáciu iba pomocou klávesnice
- **Bonus**: Zmeňte tému aplikácie medzi svetlou a tmavou

- musime vlastne ked si vybiremie temu čiže pridame addeventlistener a tema na ktoru sme klikli , musi počitač vedieť že sme na nu klikli
- musime mať uložene správne odpovede v poli a počitač musi vedieť ktorá je správna , tam kde je správna nam bude pisať error
- a tam kde správna bude chcecked image 
ak klikneme na dalšiu otázku musia sa nam to zmeniť asi cez innerHtml alebo append 
ak skončime musi nam prisť vyhodnotenie že koľko mame bodov z 10
a vyskoči nam taktiež tlačidlo play again ak klikneme nanho zase si bude mocť vybrať zo štyroch tem
 
*/

const toggleSwitch = document.getElementById('switcher');

function switchMode(event) {
    if (event.target.checked) {
        document.documentElement.classList.add('dark-theme');
        document.documentElement.classList.remove('light-theme');
        localStorage.setItem('theme', 'dark');
        document.getElementById('sun-light').classList.add('hidden');
        document.getElementById('sun-dark').classList.remove('hidden');
        document.getElementById('moon-light').classList.remove('hidden');
        document.getElementById('moon-dark').classList.add('hidden');
    } else {
        document.documentElement.classList.add('light-theme');
        document.documentElement.classList.remove('dark-theme');
        localStorage.setItem('theme', 'light');
        document.getElementById('sun-light').classList.remove('hidden');
        document.getElementById('sun-dark').classList.add('hidden');
        document.getElementById('moon-light').classList.add('hidden');
        document.getElementById('moon-dark').classList.remove('hidden');
    }
}

toggleSwitch.addEventListener('change', switchMode);

function applySavedTheme() {
    const savedTheme = localStorage.getItem('theme');

    if (savedTheme === 'dark') {
        document.documentElement.classList.add('dark-theme');
        document.documentElement.classList.remove('light-theme');
        toggleSwitch.checked = true;
        document.getElementById('sun-light').classList.add('hidden');
        document.getElementById('sun-dark').classList.remove('hidden');
        document.getElementById('moon-light').classList.remove('hidden');
        document.getElementById('moon-dark').classList.add('hidden');
    } else {
        document.documentElement.classList.add('light-theme');
        document.documentElement.classList.remove('dark-theme');
        toggleSwitch.checked = false;
        document.getElementById('sun-light').classList.remove('hidden');
        document.getElementById('sun-dark').classList.add('hidden');
        document.getElementById('moon-light').classList.add('hidden');
        document.getElementById('moon-dark').classList.remove('hidden');
    }
}

applySavedTheme();

let quizData;
let currentQuiz;
let score = 0;
let acceptingAnswers = true;
let currentQuestionIndex = {};
const submit_button = document.querySelector('.sbn-btn');



// cannot change variables

const Max_Questions = 10;


fetch('./data.json')
    .then(response => response.json())
    .then(data => {
        quizData = data;
        currentQuiz = quizData.quizzes[0]; // tuna štartujeme s prvym kvizom
        loadProgress();
        loadQuestion();
    })
    .catch(error => console.error('Error loading quiz data:', error));

function loadProgress() {
    const savedQuizIndex = localStorage.getItem('currentQuizIndex');
    const savedQuestionIndex = localStorage.getItem('currentQuestionIndex');

    if (savedQuizIndex !== null && savedQuestionIndex !== null) { // ak savedquiz index nieje prazdy a tak isto index otazky
        const quizIndex = parseInt(savedQuizIndex); // tak si to uložime do premennej a premenime zo stringu na cele čislo
        const questionIndex = parseInt(savedQuestionIndex);// tuna tiež čislo indexu otazky prerobime na cele čislo zo stringu


        if (quizIndex >= 0 && quizIndex < quizData.quizzes.length) {
            currentQuiz = quizData.quizzes[quizIndex];
        }

        if (questionIndex >= 0 && questionIndex < currentQuiz.questions.length) {
            currentQuestionIndex = questionIndex;
        }
    }
}

function saveProgress() {
    const quizIndex = quizData.quizzes.indexOf(currentQuiz);
    localStorage.setItem('currentQuizIndex', quizIndex);
    localStorage.setItem('currentQuestionIndex', currentQuestionIndex);
}

function loadQuestion() { // toto je funkcia ktorá načita otazky
    const questionData = currentQuiz.questions[currentQuestionIndex];

    let questionHTML = `<h2>${questionData.question}</h2><ul>`;


    const alphabet = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']; // tuna su možnosti 

    questionData.options.forEach((option, index) => {
        const optionLetter = alphabet[index];
        questionHTML += `<li><button class="data-answer" data-answer="${optionLetter}">${optionLetter}. ${option}</button></li>`;
    });

    questionHTML += `</ul>`;

    console.log(questionData)



    document.getElementById('content').innerHTML = questionHTML;
    document.getElementById('question_count').textContent = `Question ${currentQuestionIndex + 1} of ${currentQuiz.questions.length}`;
    document.getElementById('progress_bar').style.width = `${((currentQuestionIndex + 1) / currentQuiz.questions.length) * 100}%`;
    document.getElementById('progress_container').style.display = 'block';

    document.querySelectorAll('#content .quiz-option').forEach(button => {
        button.addEventListener('click', handleOptionClick);
    });

    const answersList = document.querySelector("ul");


    answersList.addEventListener('click', (e) => {
        const option = e.target;

        submit_button.style.display = "block"

        const isSet = option.classList.contains('active');
        for (const { classList } of answersList.children) {
            classList.remove('active');
        }
        option.classList.toggle('active', !isSet);
    });
}



submit_button.addEventListener('click', (e) => {

    function handleOptionClick(event) {
        const selectedAnswer = event.target.getAttribute('data-answer');
        const correctAnswer = currentQuiz.questions[currentQuestionIndex].answer;

        if (selectedAnswer === correctAnswer) {
            optionLetter.innerHTML = `<div class="checked">
            <img src="assets/images/wrong.png"></img></div>`
        } else {
            console.log("Incorrect!");
        }

        currentQuestionIndex++;
        if (currentQuestionIndex < currentQuiz.questions.length) {
            saveProgress();
            loadQuestion();
        } else {
            loadQuestion();

        }
    }

})


function showQuizResults() {
    document.getElementById('content').innerHTML = `<h2>Quiz Completed!</h2>`;

}



