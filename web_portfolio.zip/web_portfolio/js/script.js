"use strict";


/*čiže chcem že ak klikneme ked je tam prvy mesiačik tak nam spravi overlay
a zaroven skryty bude opacity:0 a ten mesiačik bude opacity:1.
naopak to bude rovnako, čiže ked kliknem na svetlo bude mesiačik display block
a svetlo display none a bude zase default color.*/


/*na kliknutie prejde pekne na sekciu 

čiže ak klikneme na Domov li tak chceme
aby nas to dalo na tu sekciu domov ale pekne plynulo 
ako s tou šipkou z hora dole 
čiže potrebuje vedieť vyšku od vrchu a taktieť vyšku okna
a vypisať si do konzoly vyšky okien všetky 
potrebujeme si ziskať atribut z elementu href
*/

const navigacia = $("header nav li")
const hl_nav = $("header nav")


let prepinac = $("#prepinačsvetlosti");
let prvy = $(".prvy");
let skryty = $(".skryty");

let isPrvyVisible = true;

prepinac.click(function () {
    if (isPrvyVisible) {
        skryty.addClass("aktivny");
        skryty.css('opacity', '1');
        prvy.css('opacity', '0');
        $(".hero").addClass("prekritie");
        $("html").addClass("dark")
        isPrvyVisible = false;
    } else {
        skryty.removeClass("aktivny");
        skryty.css('opacity', '0');
        prvy.css('opacity', '1');
        $(".hero").removeClass("prekritie");
        $("html").removeClass("dark")
        isPrvyVisible = true;
    }
});


/*mobilne menu*/

$(document).ready(function () {
    let ikonka = $(".ciarky");
    let menu = $("header nav li");
    let zoznam = $("nav ul").not(".dropdown-content");
    let zmena = $(".krizik");
    let panel = $("nav");


    ikonka.click(function () {
        zoznam.slideDown(300);
        ikonka.css('opacity', '0');
        zmena.css('display', 'block');
        panel.addClass("overlay1"); // Apply overlay to the nav element
    });

    zmena.click(function () {
        zoznam.slideUp(300);
        ikonka.css('opacity', '1');
        zmena.css('display', 'none');
        panel.removeClass("overlay1");

    });
});


/*od vrchu sfarbenie menu*/
$(document).ready(function () {
    let hlavicka = $("#header");
    let win = $(window);
    let menu = $("nav a");

    hlavicka.removeClass("trieda sticked");

    if (hlavicka.length > 0) {
        win.on("scroll", function () {
            console.log("ScrollY:", window.scrollY);
            if (window.scrollY > 2) {
                console.log("Adding classes");
                hlavicka.addClass("trieda sticked");
                menu.css('color', '#414a4c');
            } else {
                console.log("Removing classes");
                hlavicka.removeClass("trieda sticked");
                menu.css('color', 'white');
            }
        });
    }
});


/*
animacia na scrollovanie zapnutie animácie
čiže chceme aby ked som na určitej časti stranky až vtedy sa spustila animacia na tej danej sekcii.
čiže stale ked scrollnem tam kde sa nachádza dana sekcia tak vtedy to ide.
čiže bud použijeme podmienku, že ked bude od vrchu taka vzdialenosť/vyška tak až vtedy sa spusti animácia 
čiže ked scrollujem a som na určitej suradnici tak vtedy prebehne animácia.


Máme už koľko je sekcia od hora
mame už že ak sme na nejakej sekcii , že koľko je zhora
*/
let vyška = $(document).height()
console.log(vyška)

$(document).ready(function () {
    let sekcia = $(".časti_panela");
    let službyHlavny = $(".služby_hlavny");
    let čast = $(".cast_poloziek");
    let container = $("#portfolio")
    let ceny = $("#ceny")
    let počty = $("#štatistika")
    let forum = $("#forum")
    let novinky = $("#novinky")
    let kontakt = $("#kontakt")
    let animationTriggered = false;
    let lastScrollTop = 10299;
    let scrollDirectionDown = false;


    /*čiže ako by sme to mohli zjednodušiť 
    každu premmenu dame do poľa
    potom musime vytvoriť cyklus , ktory bude prechadzať každu hodnotu a spuštať animaciu
    tie hodnoty by sa dali dať do poľa

    */

    let pole_trigger = [2.5, 210, 910, 1610, 2400, 3100, 5100, 6200, 6920];


    $(window).on('scroll', function () {

        let scrollPositionY = $(this).scrollTop();
        let documentHeight = $(document).height();
        let windowHeight = $(this).height();


        let bottomPosition = documentHeight - windowHeight;


        if (scrollPositionY > bottomPosition) {
            return;

        }

        // Animation for .časti_panela
        if (scrollPositionY >= pole_trigger[0]) {

            sekcia.css({
                opacity: 1,
                transform: "translateY(-265%)"

            });
        } else {
            // sekcia.css({
            //     opacity: 0,
            //     transform: "translateY(-180%)"
            //
            // });
            // return;
        }

        // Animation for .služby_hlavny
        if (scrollPositionY >= pole_trigger[1]) {
            službyHlavny.css({
                opacity: 1,
                transform: "translateY(2%)"
            });
        } else {
            // službyHlavny.css({
            //     opacity: 0,
            //     transform: "translateY(50%)"
            // });
        }

        if (scrollPositionY >= pole_trigger[2]) {
            čast.css({
                opacity: 1,
                transform: "translateY(0%)"
            });
        } else {
            // čast.css({
            //     opacity: 0,
            //     transform: "translateY(100%)"
            // });
        }

        if (scrollPositionY >= pole_trigger[3]) {
            container.css({
                opacity: 1,
                transform: "translateY(1%)"
            });
        } else {
            // container.css({
            //     opacity: 0,
            //     transform: "translateY(100%)"
            // });
        }

        if (scrollPositionY >= pole_trigger[4]) {
            ceny.css({
                opacity: 1,
                transform: "translateY(0%)"
            });
        } else {
            // ceny.css({
            //     opacity: 0,
            //     transform: "translateY(100%)"
            // });
        }


        if (scrollPositionY >= pole_trigger[5]) {
            počty.css({
                opacity: 1,
                transform: "translateY(5%)"
            });
        } else {
            // počty.css({
            //     opacity: 0,
            //     transform: "translateY(50%)"
            // });
        }


        if (scrollPositionY >= pole_trigger[6]) {
            forum.css({
                opacity: 1,
                transform: "translateY(0%)"
            });
        } else {
            // forum.css({
            //     opacity: 0,
            //     transform: "translateY(100%)"
            // });
        }

        if (scrollPositionY >= pole_trigger[7]) {
            novinky.css({
                opacity: 1,
                transform: "translateY(0%)"
            });
        } else {
            // novinky.css({
            //     opacity: 1,
            //     transform: "translateY(50%)"
            // });
        }

        if (scrollPositionY >= pole_trigger[8]) {
            kontakt.css({
                opacity: 1,
                transform: "translateY(0%)"
            });
        } else {
            // kontakt.css({
            //     opacity: 1,
            //     transform: "translateY(50%)"
            // });
        }


    });


});


/*

  
 */

/*
čiže chceme aby sa šipka objavila ked zoscrollujeme dole
potom chceme na kliknutie šipky isť z dola hore
čiže potrebujem zistiť aku vyšku mam isť
 */

/*šipka hore*/


let zhora;
let vystrelenie;
let win = $(window);
console.log($(zhora));
console.log($(win))


win.scroll(function () {
    if ($(this).scrollTop() > 300) {
        $('#navrch').fadeIn('500');

    } else {

        $('#navrch').fadeOut('500');

    }


})


$('#navrch').on('click', function (e) {
    e.preventDefault()
    $('html, body').animate({scrollTop: 0}, 'smooth');
});

/*galeria */


/*ked klikneme na gombik všetko chceme mu pridať triedu aktivne a zobraziť všetky obrazky
ked ale klineme na dalši gombik chceme zobraziť len dve obrazky a ostatne skryť*/


$(document).ready(function () {
    $("#portfolio .button").click(function (e) {
        e.preventDefault();

        let gombik = $(this);
        gombik.addClass("aktivne").siblings().removeClass("aktivne");

        let trieda = gombik.data("triedenie");

        if (trieda === "miesto") {
            $(".miesto").show("show"); // Show all elements if 'Všetko' is clicked
        } else {
            $(".miesto").not("." + trieda).hide("slow");
            $("." + trieda).show("slow");
        }
    });
});


/*lightbox*/

let obrazky = $(".naše_prace1 img");
let šipky = $("#šipky");
let close = $(".cancels");
let currentImageIndex = 0;
let lightboxImg = $(".lightbox_img");


obrazky.click(function (e) {
    let imgSrc = $(this).attr("src");
    console.log(imgSrc);
    lightboxImg.attr("src", imgSrc);
    $("#overlay_lightbox").fadeIn(500);
    šipky.css('display', 'block');
    lightboxImg.css('display', 'block');
    close.css('display', 'block');
    currentImageIndex = obrazky.index(this);
});

close.click(function () {
    $("#overlay_lightbox").fadeOut(500);
});


function zavri(e) {
    event.preventDefault();
    $("#overlay_lightbox").fadeOut(500);

}

// Funkcia na zmenu zobrazovaného obrázku
function navigateImage(direction) {
    const imageCount = obrazky.length;
    if (direction === 'left') {
        // Ak sa pohybujeme doľava, znížime aktuálny index
        // Ak je index menší ako 0, vrátime sa na posledný obrázok
        currentImageIndex = (currentImageIndex - 1 + imageCount) % imageCount;
    } else if (direction === 'right') {
        // Ak sa pohybujeme doprava, zvýšime aktuálny index
        // Ak je index väčší ako posledný obrázok, vrátime sa na prvý obrázok


        // Aktualizujeme zdroj obrázka v lightboxe
        currentImageIndex = (currentImageIndex + 1) % imageCount;
    }
    /*aktualizujem zdroj obrazka v lightboxe*/
    lightboxImg.attr("src", obrazky.eq(currentImageIndex).attr("src"));
    /*pohyb obrazka*/
    lightboxImg.fadeIn("slow");
}

$('.šipka_vľavo').click(function () {
    navigateImage('left');
});

$('.šipka_vpravo').click(function () {
    navigateImage('right');
});

/*chceme na keydown ak je keycode vpravo alebo vľavo
aby sme prepinali obrazky do prava a ľava


*/
$(window).on("keydown", function (e) {
    if (e.keyCode == 37) {
        console.log("ahoj");
        navigateImage('left');
    }
});


$(window).on("keydown", function (e) {
    if (e.keyCode == 39) {
        console.log("ahoj");
        navigateImage('right');

    }
});

$(document).on("keydown", function (e) {
    if (e.keyCode == 27) {
        console.log("konec")
        zavri();

    }
});


/*chceme spraviť že ak klikneme na šipku vpravo čiže dalši a vyskoči nam dalši obrazok
čiže musime prvemu odobrať triedu active a pridať poslednemu obrazku triedu active





 aktualny_index vieme, čo ale chceme je aby sa stale aktualny index skryl čo je nula
 a dalši index ukazal 

ale musis si ukladat ten img element na ktorom si - globalna premenna

a potom od neho pojdes next() alebo prev() podla toho na aku sipku kliknes

a vyberies si z neho src hodnotu dajme tomu  i ked skor href by to malo byt ale tam nemas hodnoty
*/


/*akordeon efekt*/
$(document).ready(function () {

    $(".otazky").on("click", ".prva, .druha", function () {
        let parentDivik = $(this).closest('.divik');
        let text = parentDivik.find('.textos');

        // zatvorenie ostatnych divov aby iba stale na ktory kliknem sa otvoril
        $('.divik').not(parentDivik).removeClass("active").find('.textos').slideUp(1000);
        $('.divik').not(parentDivik).find('.prva').show();
        $('.divik').not(parentDivik).find('.druha').hide();

        // prepinanie medzi otvaranim a zatváranim
        parentDivik.toggleClass("active");
        if (parentDivik.hasClass("active")) {
            text.slideDown(300);
            parentDivik.find('.prva').hide();
            parentDivik.find('.druha').show();
        } else {
            text.slideUp(300);
            parentDivik.find('.prva').show();
            parentDivik.find('.druha').hide();
        }
    });
});


/*animacia počitadlo animacia čisla
 musime si vytvoriť funkciu counter , kde dame interval že ako dlho

 bude prebiehať animacia

 a taktiež potrebujeme dať funkciu ktora pripočita čisla od 0 po 231,453,521
*/


$(document).ready(function () {
    let $čislo = $(".čiselko");
    let bottom = 3260;
    let top1 = 3220;

    let counterStarted = false;

    $(window).on('scroll', function () {
        let scrollPositionY = $(this).scrollTop();

        let counterPositionFromViewport = $čislo[0].getBoundingClientRect().top;


        if (counterPositionFromViewport < 800 && counterPositionFromViewport > 200) {
            if (!counterStarted) {
                counterStarted = true;
                animuj();
            }
        }


        // if (scrollPositionY >= top1 && scrollPositionY < bottom) {
        //     animuj();
        // }

    });

    function animuj() {
        $čislo.each(function () {
            let $this = $(this);
            let start = 0;
            let end = $this.data('num');

            // Animate number from start to end
            $({num: start}).animate({num: end}, {
                duration: 2000,
                step: function (now) {
                    $this.text(Math.floor(now));
                },
                complete: function () {
                    $this.text(end);
                }
            });
        });
    }
});


/*na kliknutie slide down na sekciu ktora pripada k zoznamu

čiže chceme vedieť vyšku dokumentu plus vyšku okna;

chcem si zistiť aktualnu vyšku dokumentu plus vyšku okna
ak kliknem na odkaz ktory prislucha danej sekcii tak ma naanimuje na tu
 suradnicu koľko je zhora od stránky.
*/


/*formular validácia*/

let meno = $("#fname");
let email = $("#email");
let poslat = $("#submit");

poslat.click(function (e) {
    event.preventDefault()
    if (email.val().includes('@', '#', 'A')) {
        alert("Uspešne zaregistrovany");
    } else {
        alert("Niečo sa pokazilo");
    }

})


let dropko = $(".dropi");


dropko.mouseenter(function () {
    $(this).find(".dropdown-content").slideDown(500);
})


/*preloader*/

$(window).on("load", function () {
    setTimeout(function () {
        $("#preloader, .overlay_pre").fadeOut();
    }, 500);
});


/*kolotoč */


$(".bodka").click(function () {
    $(".bodka").removeClass("aktivny1");
    $(this).addClass("aktivny1");
});
  











