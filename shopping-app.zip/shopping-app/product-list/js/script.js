"use strict";


// pochopenie problemu ?
//Pridávať položky do košíka a odstraňovať ich
// čiže chceme ich pridavať cez innerHTML a cez remove button
//Zvyšovať / znižovať počet položiek v košíku
//Zobraziť potvrdzovacie okno objednávky po kliknutí na „Potvrdiť objednávku“
//Resetovať svoje výbery po kliknutí na „Začať novú objednávku“
//Zobraziť optimálne rozloženie rozhrania v závislosti od veľkosti obrazovky zariadenia
//Vidieť stavy pri prechode myšou a po zaostrení na všetky interaktívne prvky na stránke




// rozdelenie problemu na menšie časti ?
//
//
//
//
//

// Correctly initialize the basket as an array

let basket = [];

document.addEventListener("DOMContentLoaded", function () {
  fetch("data.json")
    .then(response => response.json())
    .then(data => {

      const productContainer = document.createElement("div");
      productContainer.id = "product-container";
      document.body.appendChild(productContainer);


      data.forEach((val, key) => {
        let item = document.createElement("div");
        item.className = "item";
        item.id = `productId${key}`;

        item.innerHTML = `
          <div class="img_product">
            <img srcset="${val.image.desktop} 1200w, ${val.image.tablet} 800w, ${val.image.mobile} 400w"
                 sizes="1200px, 800px, 400px"
                 src="${val.image.desktop}" alt="${val.name}">
          </div>
          <div class="button-wrapper" data-current-quantity="1">
            <button class="add-to-cart">
              <img src="assets/images/icon-add-to-cart.svg" alt=""> Add to Cart
            </button>
          </div>
          <p class="heading_food">${val.category}</p>
          <h2>${val.name}</h2>
          <p>$${val.price}</p>`;


        productContainer.appendChild(item);


        const buttonWrapper = item.querySelector(".button-wrapper");
        buttonWrapper.addEventListener("click", function () {
          console.log("Button clicked");


          let buttonContainer = document.createElement("div");
          buttonContainer.className = "item-quantity-wrapper";
          buttonContainer.innerHTML = `
            <button class="icon-change-quantity minus">
              <img src="assets/images/icon-decrement-quantity.svg" alt="">
            </button>
            <span class="item-quantity-number-in-add-to-cart">1</span>
            <button class="icon-change-quantity plus">
              <img src="assets/images/icon-increment-quantity.svg" alt="">
            </button>`;

          this.innerHTML = '';
          this.appendChild(buttonContainer);

          let itemQuantityNumber = buttonContainer.querySelector(".item-quantity-number-in-add-to-cart");
          let currentValue = 1;
          let card = document.getElementById("your_card");




          buttonContainer.querySelectorAll('.icon-change-quantity').forEach(icon => {
            icon.addEventListener("click", (event) => {
              itemQuantityNumber.textContent = currentValue;



              event.stopPropagation();

              if (icon.classList.contains('minus')) {
                if (currentValue > 1) {
                  currentValue--;
                  itemQuantityNumber.textContent = currentValue;
                }
              } else if (icon.classList.contains('plus')) {
                currentValue++;
                itemQuantityNumber.textContent = currentValue;
                card.innerHTML = `
                <h3 class="your-cart" style="margin:  2rem 1rem 0; font-size: 1.5rem;">Your Cart : (${currentValue})</h3>
                <p class="name" style="margin: 0.5remrem 0; font-size: 1rem;">${val.name}</p>
                <p class="prize" style="margin: 0.5rem 0; font-size: 1rem;">${currentValue} X $${val.price} = $${(currentValue * val.price).toFixed(2)}</p>
                <h4 class="order-total" style="margin: 1rem 0; font-size: 1.2rem; font-weight: bold;">Order Total: $${(currentValue * val.price).toFixed(2)}</h4>
                <button class="confirm-btn" style="padding: 0.5rem 1rem;margin-left: -1rem background-color: #007BFF; color: white; border: none; border-radius: 4px; cursor: pointer;">Confirm Order</button>
                 
                
            `;

                const window = document.querySelector(".confirm-btn")
                window.addEventListener("click", () => {
                  let overlay = document.createElement("div");
                  overlay.innerHTML = `
              <div class="overlay" style="opacity: 1;">Overlay
              <div class="box">
              </div>
              
              </div>
              `
                })


                function addToCart(id) {
                  if (card.some((item) => item.id === id)) {
                    alert("Products already in carts ")
                  }
                  else {
                    const item = item.find((product) => product.id === id)

                  }

                  card.push({
                    ...item,
                    numberOfUnits: 1
                  })
                  console.log(item)
                }
              }



            });
          });
        });
      });
    })
    .catch(error => console.error('Error fetching JSON:', error));
});
