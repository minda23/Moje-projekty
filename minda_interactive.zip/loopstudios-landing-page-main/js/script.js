document.addEventListener('DOMContentLoaded', () => {
  const burgerMenu = document.getElementById('burger-menu');
  const closeNav = document.getElementById('close-nav');
  const verticalNav = document.getElementById('vertical-nav');
  const overlay = document.getElementById('overlay');

  // Open vertical nav and overlay
  burgerMenu.addEventListener('click', () => {
    verticalNav.classList.add('active');
    overlay.classList.add('active');
  });

  // Close vertical nav and overlay
  closeNav.addEventListener('click', () => {
    verticalNav.classList.remove('active');
    overlay.classList.remove('active');
  });

  // Close nav if overlay is clicked
  overlay.addEventListener('click', () => {
    verticalNav.classList.remove('active');
    overlay.classList.remove('active');
  });
});
